/**
 * 
 */
package com.capgemini.test.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.test.entity.Student;
import com.capgemini.test.service.StudentService;

/**
 * @author mayadav
 *
 */
@Controller
public class LoginController {
	
	@Autowired
	private StudentService studentService;
	
	@RequestMapping(value = { "/"}, method = RequestMethod.GET)
    public ModelAndView welcomePage() {
        ModelAndView model = new ModelAndView();
        model.setViewName("welcome");
        return model;
    }
 
    @RequestMapping(value = { "/homePage"}, method = RequestMethod.GET)
    public ModelAndView homePage(ModelMap modelMap) {
        ModelAndView model = new ModelAndView();
        System.out.println(modelMap.get("userName"));
        Student student = studentService.getStudent((String)modelMap.get("userName"));
        
        System.out.println(modelMap.get("userName"));

        model.addObject("userName",student.getFullName());
        model.setViewName("homePage");
        return model;
    }
    
    @RequestMapping(value = "/loginPage", method = RequestMethod.GET)
    public ModelAndView student() {
       return new ModelAndView("loginPage", "command", new Student());
    }
    
    @RequestMapping(value = "/loginPage", method = RequestMethod.POST)
    public ModelAndView loginPage(@ModelAttribute("SpringWeb")Student student, ModelMap model) {
    	model.addAttribute("userName", student.getUserName());
        model.addAttribute("age", student.getAge());
        model.addAttribute("fullName", student.getFullName());
        
        studentService.addStudent(student);
        
        ModelAndView model1 = new ModelAndView();
       
      
       model1.addObject("userName",student.getFullName());
       model1.addObject("message", "Logged in to Application successfully.");
       model1.setViewName("homePage");
       return model1;
    }
 
}

