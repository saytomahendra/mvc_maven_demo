/**
 * 
 */
package com.capgemini.test.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.test.entity.Student;
import com.capgemini.test.repo.StudentRepository;

/**
 * @author mayadav
 *
 */
@Service
public class StudentService {

private List<Student> lst=new ArrayList<Student>(); 

private StudentRepository sr;

public void addStudent(Student student){
	 sr.save(student);
	 
	 lst.add(student);
}
public Student getStudent(String userName){
	
	Student student=sr.findByUserName(userName);
	
	/*for(Student  student:lst ){
		if(student.getUserName().equals(userName)){
			return student;
		}
	}*/
	return student;
}
	
}
