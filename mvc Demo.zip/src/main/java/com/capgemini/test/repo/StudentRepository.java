/**
 * 
 */
package com.capgemini.test.repo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.capgemini.test.entity.Student;
/** 
 * @author mayadav
 *
 */ 

public interface StudentRepository extends CrudRepository<Student, Long> {
	@Query
	Student findByUserName(String userName);
}

